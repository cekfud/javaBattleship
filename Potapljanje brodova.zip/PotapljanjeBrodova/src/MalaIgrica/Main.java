/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MalaIgrica;

import java.util.Random;
import java.util.Scanner;

/**
 * Pravila igre -> Ploča za igranje je 5x5, 25 blokova. Na njoj su skrivena 3
 * broda, cilj igre ih je pronaći i uništiti. Igra završava kada se svi brodovi
 * unište, ali imate 15 pokušaja
 *
 * Legenda: "~" - voda, još se nije pucalo na taj blok "*" - na taj se blok
 * pucalo, ali nije ništa pogođeno "X" - blok na koji se pucalo i pogođen je
 * brod
 *
 * @author dfucek
 */
public class Main {

    public static void main(String[] args) {

        int[][] plocazaIgru = new int[5][5];
        int[][] brodovi = new int[3][2];
        int[] shoot = new int[2];
        int pokušaj = 0;
        int pogođeniShot = 0;

        Scanner sc = new Scanner(System.in);

        postaviPlocu(plocazaIgru);
        postaviBrodove(brodovi);

        do {
            pokaziPlocu(plocazaIgru);
            pucaj(shoot, sc);
            pokušaj++;

            if (pogodak(brodovi, shoot)) {
                pogođeniShot++;
            }

            izmijeniIzgledPloce(shoot, brodovi, plocazaIgru);
        } while (pokušaj <= 15);

    }

    /**
     * Metoda koja uzima polje brodova i stavlja ih nasumično na ploču za igru
     *
     * @param brodovi
     */
    private static void postaviBrodove(int[][] brodovi) {
        Random var = new Random();

        for (int i = 0; i < brodovi.length; i++) {
            brodovi[i][0] = var.nextInt(5);
            brodovi[i][1] = var.nextInt(5);

            for (int j = 0; j < i; j++) {
                if (brodovi[i][0] == brodovi[j][0] && brodovi[i][1] == brodovi[j][1]) {
                    do {
                        brodovi[i][0] = var.nextInt(5);
                        brodovi[i][1] = var.nextInt(5);
                    } while ((brodovi[i][0] == brodovi[j][0]) && (brodovi[i][1] == brodovi[j][1]));
                }
            }

        }

    }

    /**
     * Metoda koja popuni 2D polje integera s '-1'
     *
     * @param plocazaIgru - polje za igru 5x5 kao 2D polje
     */
    private static void postaviPlocu(int[][] plocazaIgru) {
        for (int i = 0; i < plocazaIgru.length; i++) {
            for (int j = 0; j < plocazaIgru.length; j++) {
                plocazaIgru[i][j] = -1;
            }

        }
    }

    /**
     * Metoda koja nam pokazuje broj redaka i stupaca te prikazuje cijelu ploču
     * za igranje 5x5 popunjenu "~", "*" ili "X" znakovima
     *
     * @param plocazaIgru
     */
    private static void pokaziPlocu(int[][] plocazaIgru) {
        System.out.println("\t1 \t2 \t3 \t4 \t5");
        System.out.println();

        for (int i = 0; i < plocazaIgru.length; i++) {
            System.out.println((i + 1) + "");
            for (int j = 0; j < plocazaIgru.length; j++) {
                if (plocazaIgru[i][j] == -1) {
                    System.out.print("\t" + "~");
                } else if (plocazaIgru[i][j] == 0) {
                    System.out.print("\t" + "*");
                } else if (plocazaIgru[i][j] == 1) {
                    System.out.print("\t" + "X");
                }
            }
            System.out.println();
        }

    }

    /**
     * Metoda koja zatraži od igrača da zapuca te sprema vrijednosti u polje
     *
     * @param shoot - polje integera s veličinom 2 gdje se sprema podaci od
     * igrača
     * @param sc
     */
    private static void pucaj(int[] shoot, Scanner sc) {
        System.out.println("Upiši red: ");
        shoot[0] = sc.nextInt();
        shoot[0]--;

        System.out.println("Upiši stupac: ");
        shoot[1] = sc.nextInt();
        shoot[1]--;

    }

    /**
     * MEtoda koja provjerava je li pokušaj pucanja na brod pogodio koji brod na
     * ploči
     *
     * @param brodovi
     * @param shoot
     * @return
     */
    private static boolean pogodak(int[][] brodovi, int[] shoot) {
        for (int i = 0; i < brodovi.length; i++) {
            if (shoot[0] == brodovi[i][0] && shoot[1] == brodovi[i][1]) {
                System.out.println("Bravo, pogodili ste brod!");
                return true;
            }

        }
        return false;
    }

    /**
     * Nakon što korisnik unese stupac i redak gdje će pucati, pokaže mu se
     * ploča i izmijeni se mjesto na ploči gdje je korisnik zapucao, promašaj
     * ili pogodak
     *
     * @param shoot
     * @param brodovi
     * @param plocazaIgru
     */
    private static void izmijeniIzgledPloce(int[] shoot, int[][] brodovi, int[][] plocazaIgru) {
        if (pogodak(brodovi, shoot)) {
            plocazaIgru[shoot[0]][shoot[1]] = 1;
        } else {
            plocazaIgru[shoot[0]][shoot[1]] = 0;
        }
    }
}
